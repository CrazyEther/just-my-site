from django.apps import AppConfig


class AnimeConfig(AppConfig):
    name = 'anime'
